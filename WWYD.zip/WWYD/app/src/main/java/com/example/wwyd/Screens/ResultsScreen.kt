package com.example.wwyd.Screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.wwyd.Data.ScenarioData
import com.example.wwyd.Data.ScenarioRepository
import com.example.wwyd.ui.theme.WWYDTheme

// Data structure to hold user's answers
data class AnswerResult(val scenarioId: Int, val userAnswer: String, val isCorrect: Boolean)

@Composable
fun ResultsScreen(results: List<AnswerResult>, navController: NavHostController) {
    val totalQuestions = results.size
    val correctAnswers = results.count { it.isCorrect }
    val incorrectAnswers = totalQuestions - correctAnswers

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Display the results summary
        Text(
            text = "Results",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Text("Correct Answers: $correctAnswers/$totalQuestions", style = MaterialTheme.typography.bodyLarge)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Incorrect Answers: $incorrectAnswers/$totalQuestions", style = MaterialTheme.typography.bodyLarge)

        Spacer(modifier = Modifier.height(24.dp))

        // List of answered scenarios with right/wrong markers
        LazyColumn {
            items(results) { result ->
                val scenario = ScenarioRepository.getScenarioById(result.scenarioId) // Fetch scenario from repo
                scenario?.let {
                    ScenarioResultItem(
                        scenario = it,
                        userAnswer = result.userAnswer,
                        isCorrect = result.isCorrect
                    )
                }
            }
        }

        // Button to go back to home or restart the game
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = {
                navController.navigate("home") // Navigate back to Home screen
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back to Home")
        }
    }
}

@Composable
fun ScenarioResultItem(scenario: ScenarioData, userAnswer: String, isCorrect: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Text(
            text = "Scenario: ${scenario.situation}",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        Text(
            text = "Your Answer: $userAnswer",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        Text(
            text = if (isCorrect) "Correct!" else "Incorrect",
            style = MaterialTheme.typography.bodySmall,
            color = if (isCorrect) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
    }
}
