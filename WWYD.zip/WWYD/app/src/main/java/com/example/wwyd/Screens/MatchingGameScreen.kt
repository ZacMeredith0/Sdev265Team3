package com.example.wwyd.Screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.wwyd.R
import com.example.wwyd.ui.theme.WWYDTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WWYDTheme {
                MatchingGameScreen()
            }
        }
    }
}

@Composable
fun MatchingGameScreen() {
    // Game state variables
    var cards by remember { mutableStateOf(shuffledEmotionCards()) }
    var selectedIndices by remember { mutableStateOf(listOf<Int>()) }
    var matchedIndices by remember { mutableStateOf(setOf<Int>()) }
    val coroutineScope = rememberCoroutineScope()

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // Background Image
        Image(
            painter = painterResource(id = R.drawable.background),
            contentDescription = "Background",
            modifier = Modifier.fillMaxSize()
        )

        // Overlay with game content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Matching Game",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            EmotionCardGrid(
                cards = cards,
                selectedIndices = selectedIndices,
                matchedIndices = matchedIndices,
                onCardSelected = { index ->
                    if (index !in selectedIndices && index !in matchedIndices) {
                        // Update selectedIndices by adding the new card index
                        selectedIndices = selectedIndices + index

                        // Check for match
                        if (selectedIndices.size == 2) {
                            val firstCard = cards[selectedIndices[0]]
                            val secondCard = cards[selectedIndices[1]]
                            if (firstCard.imageRes == secondCard.imageRes) {
                                // Cards match, add indices to matched set
                                matchedIndices = matchedIndices + selectedIndices
                            }

                            // Delay to show cards before hiding them again
                            coroutineScope.launch {
                                delay(1000L)
                                selectedIndices = listOf() // Reset selected indices
                            }
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Reset Button
            Button(
                onClick = {
                    // Reset the game
                    cards = shuffledEmotionCards()
                    selectedIndices = listOf()
                    matchedIndices = setOf()
                }
            ) {
                Text(text = "Reset Game")
            }

            // Game Over Message
            if (matchedIndices.size == cards.size / 2) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "Game Over! You matched all the cards!", style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

@Composable
fun EmotionCardGrid(
    cards: List<EmotionCard>,
    selectedIndices: List<Int>,
    matchedIndices: Set<Int>,
    onCardSelected: (Int) -> Unit
) {
    val columns = 4 // Adjust the grid size if necessary
    val rows = cards.chunked(columns)

    Column {
        rows.forEachIndexed { rowIndex, row ->
            Row(
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                row.forEachIndexed { columnIndex, card ->
                    val index = rowIndex * columns + columnIndex
                    val isMatched = index in matchedIndices
                    val isSelected = index in selectedIndices

                    EmotionCardItem(
                        card = if (isMatched || isSelected) card else null,
                        isMatched = isMatched,
                        onClick = { if (!isMatched && index !in selectedIndices) onCardSelected(index) }
                    )
                }
            }
        }
    }
}

@Composable
fun EmotionCardItem(card: EmotionCard?, isMatched: Boolean, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .padding(8.dp)
            .size(100.dp)
            .clickable(enabled = card != null && !isMatched, onClick = onClick),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            if (card != null) {
                Image(
                    painter = painterResource(id = card.imageRes),
                    contentDescription = card.name,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(
                    text = "?",
                    fontSize = 24.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

data class EmotionCard(val name: String, val imageRes: Int)

fun shuffledEmotionCards(): List<EmotionCard> {
    val emotions = listOf(
        EmotionCard("Disgust", R.drawable.disgust),
        EmotionCard("Angry", R.drawable.angry),
        EmotionCard("Happy", R.drawable.happy),
        EmotionCard("Sad", R.drawable.sad),
        EmotionCard("Anxiety", R.drawable.anxiety)
    )
    return (emotions + emotions).shuffled(Random(System.currentTimeMillis()))
}
