package com.example.wwyd.Screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.wwyd.Data.ScenarioRepository

@Composable
fun ScenarioList() {
    val scenarios = ScenarioRepository.getAllScenarios()

    LazyColumn(
        modifier = Modifier.padding(8.dp)
    ) {
        items(scenarios) { scenario ->
            ScenarioItem(
                situation = scenario.situation,
                choices = scenario.choices
            )
            Spacer(modifier = Modifier.height(16.dp)) // Space between scenarios
        }
    }
}

@Composable
fun ScenarioItem(situation: String, choices: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Text(
            text = situation,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(8.dp))
        choices.forEachIndexed { index, choice ->
            Text(
                text = "Choice ${index + 1}: $choice",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}
