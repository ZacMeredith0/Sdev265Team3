package com.example.wwyd.Screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.* // Updated import for layout utilities
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.wwyd.R
import com.example.wwyd.ui.theme.WWYDTheme
import kotlinx.coroutines.delay

class BreathingExerciseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WWYDTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BreathingExerciseScreen()
                }
            }
        }
    }
}

@Composable
fun BreathingExerciseScreen() {
    var isBreathing by remember { mutableStateOf(false) }
    var instruction by remember { mutableStateOf("Press Start to begin!") }
    var isExerciseComplete by remember { mutableStateOf(false) }

    val breathingSteps = listOf(
        "Breathe in... 🌬️" to 6000L,  // 6 seconds
        "Hold your breath... 🤐" to 6000L,
        "Breathe out... 😮‍💨" to 6000L
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // Background Image
        Image(
            painter = painterResource(id = R.drawable.background2), // Replace with your background image
            contentDescription = "Background",
            modifier = Modifier.fillMaxSize()
        )

        // Dark Overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
        )

        // Main Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!isBreathing && !isExerciseComplete) {
                // Start Button
                Button(
                    onClick = {
                        isBreathing = true
                        isExerciseComplete = false // Reset the state for a new session
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Start Breathing Exercise", style = MaterialTheme.typography.bodyLarge)
                }
            } else if (isBreathing) {
                // Breathing Exercise in Progress
                LaunchedEffect(isBreathing) {
                    for ((text, duration) in breathingSteps) {
                        if (!isBreathing) break  // Exit loop if stopped
                        instruction = text
                        delay(duration)
                    }

                    // Reset state automatically when finished
                    if (isBreathing) {
                        isBreathing = false
                        isExerciseComplete = true
                        instruction = "Press Start to begin!" // Reset instruction after completion
                    }
                }

                // Display Instruction
                Text(
                    text = instruction,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    modifier = Modifier.padding(16.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Stop Button
                Button(
                    onClick = {
                        isBreathing = false
                        isExerciseComplete = true
                        instruction = "Exercise Stopped. Press Start to begin again!"
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Stop Exercise", style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
