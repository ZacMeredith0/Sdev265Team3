package com.example.wwyd.Screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.wwyd.Data.ScenarioRepository
import com.example.wwyd.ui.theme.WWYDTheme

class HomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WWYDTheme {
                // Wrapping the ScenarioList in a Surface for proper theming
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ScenarioList()
                }
            }
        }
    }
}
@Preview(showBackground = true)
@Composable
fun PreviewScenarioList() {
    WWYDTheme {
        ScenarioList()
    }
}
