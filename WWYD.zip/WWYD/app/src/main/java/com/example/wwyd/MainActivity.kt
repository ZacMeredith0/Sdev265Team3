package com.example.wwyd

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.wwyd.Screens.HomeActivity
import com.example.wwyd.ui.theme.WWYDTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WWYDTheme {
                Scaffold { innerPadding ->
                    MainScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun MainScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Title
        Text(
            text = "WWYD App",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        // App Icon (Clickable to navigate to HomeActivity)
        Image(
            painter = painterResource(id = R.drawable.app_icon), // Ensure this resource exists
            contentDescription = "App Icon",
            modifier = Modifier
                .size(100.dp)
                .clickable {
                    context.startActivity(Intent(context, HomeActivity::class.java))
                }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    WWYDTheme {
        MainScreen(
            modifier = Modifier.fillMaxSize()
        )
    }
}
