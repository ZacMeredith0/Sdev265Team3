package com.example.wwyd.Data




data class ScenarioData(val id: Int, val situation: String, val choices: List<String>)
