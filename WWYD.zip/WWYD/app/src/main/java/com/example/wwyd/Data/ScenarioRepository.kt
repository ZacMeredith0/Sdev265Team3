package com.example.wwyd.Data

object ScenarioRepository {
    private val scenarios = listOf(
        ScenarioData(
            id = 1,
            situation = "You see a classmate sitting alone at lunch.",
            choices = listOf(
                "You sit with them and start a friendly conversation.",
                "You ignore them and sit with your other friends.",
                "You invite them to join your group of friends."
            ),
            correctAnswer = "You sit with them and start a friendly conversation." // Added correct answer
        ),
        ScenarioData(
            id = 2,
            situation = "You notice a friend struggling with their homework.",
            choices = listOf(
                "You offer to help explain the homework to them.",
                "You do the homework for them.",
                "You suggest they ask the teacher for extra help."
            ),
            correctAnswer = "You offer to help explain the homework to them." // Added correct answer
        ),
        ScenarioData(
            id = 3,
            situation = "You find a lost toy on the playground.",
            choices = listOf(
                "You leave it where it is in case the owner returns.",
                "You take it to the lost and found.",
                "You keep it for yourself."
            ),
            correctAnswer = "You take it to the lost and found." // Added correct answer
        ),
        ScenarioData(
            id = 4,
            situation = "Your friend is nervous about presenting in front of the class.",
            choices = listOf(
                "You offer to practice with them to boost their confidence.",
                "You tell them they'll be fine without help.",
                "You suggest they skip the presentation if they're too scared."
            ),
            correctAnswer = "You offer to practice with them to boost their confidence." // Added correct answer
        ),
        ScenarioData(
            id = 5,
            situation = "You see someone accidentally drop their phone in the hallway.",
            choices = listOf(
                "You pick it up and give it back to them.",
                "You leave it on the ground for them to notice.",
                "You keep it for yourself."
            ),
            correctAnswer = "You pick it up and give it back to them." // Added correct answer
        ),
        ScenarioData(
            id = 6,
            situation = "You’re at a friend’s house, and they want to watch a scary movie.",
            choices = listOf(
                "You politely tell them you're uncomfortable and suggest another movie.",
                "You agree to watch it, even though you’re scared.",
                "You pretend to feel sick and leave."
            ),
            correctAnswer = "You politely tell them you're uncomfortable and suggest another movie." // Added correct answer
        ),
        ScenarioData(
            id = 7,
            situation = "You see someone being excluded from a group activity.",
            choices = listOf(
                "You invite them to join your group instead.",
                "You don’t get involved since it’s not your problem.",
                "You talk to the others about including everyone."
            ),
            correctAnswer = "You invite them to join your group instead." // Added correct answer
        ),
        ScenarioData(
            id = 8,
            situation = "Your sibling accidentally breaks your favorite toy.",
            choices = listOf(
                "You forgive them and try to fix it together.",
                "You get angry and refuse to talk to them.",
                "You ask them to help replace it."
            ),
            correctAnswer = "You forgive them and try to fix it together." // Added correct answer
        ),
        ScenarioData(
            id = 9,
            situation = "You’re at a party, and someone offers you a drink you’re unsure about.",
            choices = listOf(
                "You politely decline and stick with what you’re comfortable with.",
                "You take the drink to fit in.",
                "You make up an excuse and walk away."
            ),
            correctAnswer = "You politely decline and stick with what you’re comfortable with." // Added correct answer
        ),
        ScenarioData(
            id = 10,
            situation = "You see a friend litter in the park.",
            choices = listOf(
                "You ask them to pick it up and throw it in the trash.",
                "You pick it up yourself and throw it away.",
                "You ignore it because it’s not your trash."
            ),
            correctAnswer = "You ask them to pick it up and throw it in the trash." // Added correct answer
        )
    )

    // Function to get all scenarios
    fun getAllScenarios(): List<ScenarioData> {
        return scenarios
    }

    // Function to get a scenario by ID
    fun getScenarioById(id: Int): ScenarioData? {
        return scenarios.find { it.id == id }
    }
}
